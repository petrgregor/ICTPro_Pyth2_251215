# My awesome package

## Installation
pip install my_awesome_package

## Description
